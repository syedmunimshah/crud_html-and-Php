<?php
//  error_reporting(0);
 $stu_name = $_POST['sname'];
 $stu_address = $_POST['saddress'];
 $stu_class = $_POST['class'];
 $stu_phone = $_POST['sphone'];

$conn = mysqli_connect("localhost","root","","crud") or die("Connectin Failed");
$query= "INSERT INTO `student`(`sname`, `saddress`, `sclass`, `sphone`) VALUES('{$stu_name}','{$stu_address}','{$stu_class}','{$stu_phone}')";
$result = mysqli_query($conn,$query) or die("query unsuccessfull.");

//  if(mysqli_query($conn, $query)){
//    echo"true";
      
// } else {
//        echo mysqli_error($conn);
   
//  }

header("Location:http://localhost/PHP_CODE_PROJECT/crud_html/index.php");
mysqli_close($conn);



?>