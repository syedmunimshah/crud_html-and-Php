<?php

 $stu_id= $_GET['id'];


$conn = mysqli_connect("localhost","root","","crud") or die("Connectin Failed");
$sql= "DELETE FROM student WHERE sid={$stu_id}";
$result = mysqli_query($conn,$sql) or die("query unsuccessfull.");

header("Location:http://localhost/PHP_CODE_PROJECT/crud_html/index.php");
mysqli_close($conn);


?>